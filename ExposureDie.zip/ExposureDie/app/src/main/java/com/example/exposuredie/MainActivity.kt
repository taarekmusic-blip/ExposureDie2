package com.example.exposuredie

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.random.Random

class MainActivity : Activity() {

    // ۱۲ وجه: ۱ گازگرفتگی، ۲ سرمازدگی، ۳ زخم، ۶ خالی
    private val die = listOf(0) + List(2) { 1 } + List(3) { 2 } + List(6) { 3 }
    private val names = listOf("گازگرفتگی", "سرمازدگی", "زخم", "خالی")
    private val counts = IntArray(4)
    private val countViews = arrayOfNulls<TextView>(4)
    private val handler = Handler(Looper.getMainLooper())
    private var busy = false

    private lateinit var dieView: DieView
    private lateinit var result: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#10171D"))
            setPadding(dp(16), dp(32), dp(16), dp(16))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        root.addView(TextView(this).apply {
            text = "تاس مواجهه با محیط"; textSize = 22f
            setTextColor(Color.WHITE); gravity = Gravity.CENTER
        })

        dieView = DieView(this).apply { setOnClickListener { roll() } }
        root.addView(dieView, LinearLayout.LayoutParams(dp(280), dp(280)).apply {
            topMargin = dp(32); bottomMargin = dp(16)
        })

        result = TextView(this).apply {
            textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }
        root.addView(result)
        root.addView(TextView(this).apply {
            text = "برای پرتاب تاس روی آن بزنید"; textSize = 14f
            setTextColor(Color.parseColor("#9BB0BF")); gravity = Gravity.CENTER
        })

        val tally = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0 until 4) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setBackgroundColor(Color.parseColor("#1A242C"))
                setPadding(dp(4), dp(8), dp(4), dp(8))
            }
            cell.addView(TextView(this).apply {
                text = names[i]; textSize = 13f; setTextColor(Color.parseColor("#9BB0BF"))
            })
            val c = TextView(this).apply { text = "0"; textSize = 20f; setTextColor(Color.WHITE) }
            countViews[i] = c; cell.addView(c)
            tally.addView(cell, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        }
        root.addView(tally, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(32) })

        root.addView(Button(this).apply {
            text = "صفر کردن شمارنده"
            setOnClickListener { counts.fill(0); refresh(); result.text = "" }
        }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(16) })

        setContentView(root)
        dieView.face = 3
    }

    private fun refresh() { for (i in 0 until 4) countViews[i]?.text = counts[i].toString() }

    private fun roll() {
        if (busy) return
        busy = true
        result.text = ""
        dieView.animate().rotationBy(360f).setDuration(700).withEndAction { dieView.rotation = 0f }.start()
        var n = 0
        val tick = object : Runnable {
            override fun run() {
                dieView.face = die[Random.nextInt(12)]
                if (++n < 8) handler.postDelayed(this, 80) else finishRoll()
            }
        }
        handler.post(tick)
    }


    private fun finishRoll() {
        handler.postDelayed({
            val r = die[Random.nextInt(12)]
            dieView.face = r
            counts[r]++
            refresh()
            result.text = names[r]
            busy = false
        }, 80)
    }
}
