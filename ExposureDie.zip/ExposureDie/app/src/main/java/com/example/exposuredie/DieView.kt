package com.example.exposuredie

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** 0 = گازگرفتگی، 1 = سرمازدگی، 2 = زخم، 3 = خالی */
class DieView(context: Context) : View(context) {

    var face = 3
        set(v) { field = v; invalidate() }

    private val C_FACE = Color.parseColor("#25323C")
    private val C_EDGE = Color.parseColor("#8FA3B3")
    private val C_BITE = Color.parseColor("#E0A84A")
    private val C_FROST = Color.parseColor("#6CC4FF")
    private val C_WOUND = Color.parseColor("#FF6B60")
    private val C_BLANK = Color.parseColor("#9BB0BF")

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }

    private val dodeca = Path().apply {
        for (i in 0 until 12) {
            val a = (i * 30 - 90) * PI / 180
            val x = (100 + 92 * cos(a)).toFloat()
            val y = (100 + 92 * sin(a)).toFloat()
            if (i == 0) moveTo(x, y) else lineTo(x, y)
        }
        close()
    }

    private val tooth = Path().apply {
        moveTo(55f, 70f)
        cubicTo(55f, 56f, 67f, 50f, 80f, 53f)
        cubicTo(94f, 57f, 106f, 57f, 120f, 53f)
        cubicTo(133f, 50f, 145f, 56f, 145f, 70f)
        cubicTo(145f, 90f, 137f, 96f, 134f, 116f)
        cubicTo(132f, 126f, 128f, 138f, 122f, 138f)
        cubicTo(115f, 138f, 117f, 112f, 105f, 112f)
        cubicTo(93f, 112f, 95f, 138f, 88f, 138f)
        cubicTo(82f, 138f, 78f, 126f, 76f, 116f)
        cubicTo(73f, 96f, 55f, 90f, 55f, 70f)
        close()
    }

    private val drop = Path().apply {
        moveTo(100f, 40f)
        cubicTo(122f, 72f, 140f, 92f, 140f, 116f)
        arcTo(RectF(60f, 76f, 140f, 156f), 0f, 180f)
        cubicTo(60f, 92f, 78f, 72f, 100f, 40f)
        close()
    }

    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height) / 200f
        canvas.save()
        canvas.translate((width - 200 * s) / 2, (height - 200 * s) / 2)
        canvas.scale(s, s)

        fill.color = C_FACE
        canvas.drawPath(dodeca, fill)
        stroke.color = C_EDGE; stroke.strokeWidth = 5f
        canvas.drawPath(dodeca, stroke)
        stroke.alpha = 70; stroke.strokeWidth = 2f
        canvas.save(); canvas.scale(0.82f, 0.82f, 100f, 100f)
        canvas.drawPath(dodeca, stroke); canvas.restore()

        when (face) {
            0 -> { // گازگرفتگی: دندان
                fill.color = C_FACE; canvas.drawPath(tooth, fill)
                stroke.color = C_BITE; stroke.strokeWidth = 7f
                canvas.drawPath(tooth, stroke)
            }
            1 -> { // سرمازدگی: دانه برف
                stroke.color = C_FROST; stroke.strokeWidth = 8f
                for (i in 0 until 6) {
                    canvas.save(); canvas.rotate(i * 60f, 100f, 100f)
                    canvas.drawLine(100f, 100f, 100f, 45f, stroke)
                    canvas.drawLine(100f, 62f, 88f, 50f, stroke)
                    canvas.drawLine(100f, 62f, 112f, 50f, stroke)
                    canvas.restore()
                }
            }
            2 -> { // زخم: قطره خون با بریدگی
                fill.color = C_WOUND; canvas.drawPath(drop, fill)
                stroke.color = C_FACE; stroke.strokeWidth = 7f
                canvas.drawLine(82f, 112f, 118f, 134f, stroke)
                canvas.drawLine(118f, 112f, 82f, 134f, stroke)
            }
            else -> { // خالی
                fill.color = C_BLANK; canvas.drawCircle(100f, 100f, 6f, fill)
            }
        }
        canvas.restore()
    }
}
