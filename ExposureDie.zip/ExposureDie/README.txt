Android Studio: File > Open > پوشه ExposureDie را باز کنید و Sync را بزنید.
Build > Build Bundle(s) / APK(s) > Build APK(s)
فایل خروجی: app/build/outputs/apk/debug/app-debug.apk
